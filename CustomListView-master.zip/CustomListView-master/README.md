# CustomListView
Custom Listview with custom design also supportable for API implementing

## Android Screenshot
<img src="/Image/Screenshot.jpg" width="300" height="600"> 

## Important
* Don't Forget to give Internet permission from AndroidManifest.xml file for using internet access
* Add Picasso libreary to your app for loading online Image

## Thanks
* [Picasso][picasso] used for the sample 


[picasso]: https://github.com/square/picasso
